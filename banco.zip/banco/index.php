
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="style.css">
  <title>Document</title>
</head>
<body class="corpo">
  <h1>Login</h1>
  <div class="login">
  <form action="login.php" method="post" class="form">
    <label for="" class="user">usuario</label>
    <input type="text" name="usuario">
    <br>
    <label for="" class="senha">senha</label>
    <input type="text" name="senha" id="senha">
    <br><br>
    <input type="submit" name="enviar" class="enviar">
  </form>
  </div>
</body>
</html>
