<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Vetor</title>
</head>
<body>
  <?php
    $alunos = ["Luis", "Vermeio", "Klein"];
    echo "<pre>";
    echo var_dump($alunos);
    echo "<br>";
    print_r($alunos);
    echo "<br>";
    echo"</pre>";
    echo "<br>";
    print_r($alunos);
    echo "<br>";
    echo "<pre>";


    $cliente = ["Gabriel", 39, 1.92, true];
    print_r($cliente);
    echo var_dump($cliente);
    echo "</pre>";

    echo "<pre>";
    $cursos = [];
    $cursos[0] = "desenvolvimento de sistemas";
    $cursos[1] = "informatica";
    $cursos[2] = "eletronica lixo";
    print_r ($cursos);
    echo "</pre>";

    echo"<pre>";
    echo "<h1> funcoes para vetores </h1><br>";
    echo "escrevendo depois do array push <br>";
    array_push($alunos, "luiza", "erick");

    echo "adicionando com array unshift <br>";
    array_unshift($alunos, "andre", "eduardo");
    print_r($alunos);

    echo "apagando o ultimo com pop";
    array_pop($alunos);
    print_r($alunos);

    echo "apagando o primeiro com shift";
    array_shift($alunos);
    print_r($alunos);

    echo"</pre>";

    echo "contando os elementos <br>";
    echo count($alunos);
    $qntalunos = count($alunos);
    echo "<br>a quantidade de alunos é: $qntalunos";

    echo "<pre>";
    echo"ordenando do menor pro maior<br>";
    sort($alunos);
    print_r($alunos);
    echo "</pre>";

    echo "<pre>";
    echo"ordenando do maior pro menor<br>";
    rsort($alunos);
    print_r($alunos);
    echo "</pre>";

    for ($i=0; $i < $qntalunos ; $i++ ){
      echo "$alunos[$i] <br>"; 
        }
        echo"<br>-----------<br><br>";
        foreach ($alunos as $indice => $aluno) {
          echo "$indice : $aluno <br>";
        }
    ?>
</body>
</html>