<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pi</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função pi</h1>
    <br><br>
    <p>iAo resolver problemas matemáticos, muitas vezes nos deparamos com questões que requerem o valor de π. Inserir manualmente o valor de PI (π) pode ser demorado e incorreto. Também não é considerada uma boa prática de programação. Para resolver esse problema, uma função embutida do PHP pi() vem para ajudar.</p>
    <p class="sintaxe">echo(pi())</p>   
    <p>Exemplo:</p>
    <p class="exemplo">echo M_PI; </p>

        <?php
        echo("pi é: ");
        echo(pi());
        ?> 


</body>
</html>