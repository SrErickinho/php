<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>max</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função max</h1>
    <br><br>
    <p>A função max() do PHP é usada para encontrar o valor mais alto em um array, ou o valor mais alto de vários valores especificados. A função max() pode pegar uma matriz ou vários números como argumento e retornar o valor numericamente máximo entre os parâmetros passados. O tipo de retorno não é fixo, pode ser um valor inteiro ou um valor flutuante com base na entrada.</p>
    <p class="sintaxe">max(array_values)<br> or<br> max(value1, value2, ...) </p>   
    <p>Exemplo:</p>
    <p class="exemplo">echo (max(12, 4, 62, 97, 26)); </p>
    <p>Vamos fazer usando 5 números</p>
    <form method="get">
        <label for="abs">Insira o primeiro número</label>
        <input type="number" name="primeiro" id="primeiro" class="calculos" required>
        <br>
        <label for="abs">Insira o segundo número</label>
        <input type="number" name="segundo" id="segundo" class="calculos" required>
        <br>
        <label for="abs">Insira o terceiro número</label>
        <input type="number" name="terceiro" id="terceiro" class="calculos" required>
        <br>
        <label for="abs">Insira o quarto número</label>
        <input type="number" name="quarto" id="quarto" class="calculos" required>
        <br>
        <label for="abs">Insira o quinto número</label>
        <input type="number" name="quinto" id="primeiro" class="calculos" required>
        <input type="submit" class="enviar" value="Enviar calculo" required>

        <?php
        $primeiro= $_GET["primeiro"];
        $segundo= $_GET["segundo"];
        $terceiro= $_GET["terceiro"];
        $quarto= $_GET["quarto"];
        $quinto= $_GET["quinto"];
        echo(max( array ($primeiro, $segundo, $terceiro, $quarto, $quinto)));
        ?> 


</body>
</html>