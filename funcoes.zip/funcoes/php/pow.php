<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>pow</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função pow</h1>
    <br><br>
    <p>A função pow() em PHP é usada para calcular uma base elevada à potência do expoente. É uma função genérica que pode ser usada com o número elevado a qualquer valor. Ela usa dois parâmetros que são a base e o expoente e retorna a resposta desejada.</p>
    <p class="sintaxe">number pow($base, $exp);</p>   
    <p>Exemplo:</p>
    <p class="exemplo">echo(pow(3, 2)); </p>
    <form method="get">
        <label for="abs">Insira o valor a ser elevado(base)</label>
        <input type="number" name="base" id="base" class="calculos" required><br>
        <label for="abs">Insira o valor do expoente(a quanto vai elevar)</label>
        <input type="number" name="expoente" id="expoente" class="calculos" required>
        <input type="submit" class="enviar" value="Enviar calculo" required>

        <?php
        $base= $_GET["base"];
        $expoente= $_GET["expoente"];
        echo(pow($base, $expoente));
        ?> 


</body>
</html>