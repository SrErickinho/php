<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>base_convert</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função base_convert</h1>
    <br><br>
    <p>A função base_convert() em PHP é usada para converter um número dado em uma base arbitrária para uma base desejada. 
Ambas as bases devem estar entre 2 e 32 e as bases com dígitos maiores que 10 são representadas com letras az, ou seja, 10 é representado como a, 11 é representado como be 35 é representado como z. </p>
    <p class="sintaxe">string base_convert($inpNumber, $fromBase, $desBase) </p>   
    <p>     $inpNumber: É o número a ser convertido.
    $fromBase: É a base original do número.
    $desBase: É a base para a qual você deseja converter.</p>
    <p>Exemplo:</p>
    <p class="exemplo">$hexadec = "B296";
echo base_convert($hexadec, 16, 8); </p>
    <p> Vamos tranformar um hexadecimal em binário</p>
    <form method="get">
        <label for="primeiro">Insira o primeiro valor para base convert </label>
        <input type="text" name="primeiro" id="primeiro" class="calculos" >
        <input type="submit" class="enviar" value="Enviar calculo" >

        <?php
        $primeiro= $_GET["primeiro"];
        echo base_convert($primeiro, 16, 2);
        ?> 
        <br>
        <p>Vamos transformar o hexadecimal em octal</p>
        <label for="segundo">Insira o valor para base convert </label>
        <input type="text" name="segundo" id="segundo" class="calculos" >
        <input type="submit" class="enviar" value="Enviar calculo" >

        <?php
        $segundo= $_GET["segundo"];
        echo base_convert($segundo, 16, 8);
        ?> 

        <p>Vamos transformar o octal em hexadecimal</p>
        <label for="segundo">Insira o valor para base convert </label>
        <input type="text" name="terceiro" id="terceiro" class="calculos" >
        <input type="submit" class="enviar" value="Enviar calculo" >

        <?php
        $terceiro= $_GET["terceiro"];
        echo base_convert($terceiro, 8, 16);
        ?> 

        <p>Vamos transformar o binario em hexadecimal</p>
        <label for="quato">Insira o valor para base convert </label>
        <input type="text" name="quarto" id="quarto" class="calculos" >
        <input type="submit" class="enviar" value="Enviar calculo" >

        <?php
        $quarto= $_GET["quarto"];
        echo base_convert($quarto, 2, 16);
        ?> 


</body>
</html>