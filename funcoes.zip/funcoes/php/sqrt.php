<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sqrt</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função sqrt</h1>
    <br><br>
    <p>Muitas vezes acontece que, ao resolver expressões matemáticas, precisamos calcular a raiz quadrada de um número. 
Para resolver esse problema como outra linguagem de programação, o PHP nos fornece uma função interna sqrt() que pode ser usada para calcular a raiz quadrada de um número. A função sqrt() no PHP é usada para calcular a raiz quadrada de um número. </p>
    <p class="sintaxe">float sqrt(value);</p>   
    <p>Exemplo:</p>
    <p class="exemplo"> echo(sqrt(25)); </p>
    <p> Vamos calcular:</p>
    <form method="get">
        <label for="raiz">Insira o valor que deseja saber a raiz quadrada: </label>
        <input type="number" name="raiz" id="raiz" class="calculos" required>
        <input type="submit" class="enviar" value="Enviar calculo" required>

        <?php
        $raiz= $_GET["raiz"];
        echo (sqrt($raiz));
        ?> 


</body>
</html>