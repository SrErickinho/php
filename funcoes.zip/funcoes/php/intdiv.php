<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>intdiv</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função intdiv</h1>
    <br><br>
    <p>intdiv significa divisão inteira. Esta função retorna o quociente inteiro da divisão do dividendo e divisor fornecidos. Essa função remove internamente o restante do dividendo para torná-lo igualmente divisível pelo divisor e retorna o quociente após a divisão.</p>
    <p class="sintaxe">int intdiv($dividend, $divisor)</p>   
    <p>Exemplo:</p>
    <p class="exemplo">echo intdiv($dividend, $divisor); </p>
    <form method="get">
        <label for="abs">Insira o primeiro valor para o calculo</label>
        <input type="number" name="primeiro" id="primeiro" class="calculos" required>
        <label for="abs">Insira o valor a qual será dividido</label>
        <input type="number" name="segundo" id="segundo" class="calculos" required>
        <input type="submit" class="enviar" value="Enviar calculo" required>

        <?php
        $primeiro= $_GET["primeiro"];
        $segundo= $_GET["segundo"];
        echo(intdiv($primeiro, $segundo));
        ?> 


</body>
</html>