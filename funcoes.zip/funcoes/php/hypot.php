<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>hypot</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função hypot</h1>
    <br><br>
    <p>A função hypot() é uma função matemática embutida no PHP e retorna a raiz quadrada da soma do quadrado dos argumentos passados. Ele encontra a hipotenusa, a hipotenusa é o lado mais longo de um triângulo retângulo. É calculado pela fórmula: </p>
    <p>h=raiz quadrada de(x ao quadrado + y ao quadrado)</p>
    <p class="sintaxe">hypot(x,y);</p>   
    <p> x= cateto adjacente
        y= cateto oposto </p>
    <p>Exemplo:</p>
    <p class="exemplo">$hypotenuse = hypot(4,6);
    print_r($hypotenuse); </p>
    <p> Vamos calcular:</p>
    <form method="get">
        <label for="x">Insira o valor de x </label>
        <input type="number" name="x" id="x" class="calculos" required>
        <label for="y">Insira o valor de y </label>
        <input type="number" name="y" id="y" class="calculos" required>
        <input type="submit" class="enviar" value="Enviar calculo" required>

        <?php
        $x= $_GET["x"];
        $y= $_GET["y"];
        echo hypot($x, $y);
        ?> 


</body>
</html>