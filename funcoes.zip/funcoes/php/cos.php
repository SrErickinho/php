<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>cos</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função cos</h1>
    <br><br>
    <p>A trigonometria é uma parte importante da matemática e as funções matemáticas do PHP nos fornecem algumas funções que são muito úteis para cálculos envolvendo trigonometria. A função cos() no PHP é usada para encontrar o valor do cosseno de um número.
A função cos() retorna um valor flutuante entre -1 e 1, que representa o cosseno do ângulo passado como argumento. O parâmetro do argumento deve estar em radianos. </p>
    <p class="sintaxe">float cos($value);</p>   
    <p>Exemplo:</p>
    <p class="exemplo"> echo (cos(3)); </p>
    <p> Vamos calcular:</p>
    <form method="get">
        <label for="x">Insira o valor que deseja saber o cosseno: </label>
        <input type="number" name="cos" id="cos" class="calculos" required>
        <input type="submit" class="enviar" value="Enviar calculo" required>

        <?php
        $cos= $_GET["cos"];
        echo (cos($cos));
        ?> 


</body>
</html>