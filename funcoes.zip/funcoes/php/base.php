<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>base_convert</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função base_convert</h1>
    <br><br>
    <p>A função base_convert() em PHP é usada para converter um número dado em uma base arbitrária para uma base desejada. 
Ambas as bases devem estar entre 2 e 32 e as bases com dígitos maiores que 10 são representadas com letras az, ou seja, 10 é representado como a, 11 é representado como be 35 é representado como z. </p>
    <p class="sintaxe">string base_convert($inpNumber, $fromBase, $desBase) </p>   
    <p>     $inpNumber: É o número a ser convertido.
    $fromBase: É a base original do número.
    $desBase: É a base para a qual você deseja converter.</p>
    <p>Exemplo:</p>
    <p class="exemplo">$hexadec = "B296";
echo base_convert($hexadec, 16, 8); </p>
    <form method="get">
      <label for="numero">insira um numero</label><br>
      <input type="string" name="numero" id="numero">
      <label for="base">insira a base atual</label><br>
      <input type="int" name="base" id="base">
      <label for="numero">insira a base que será convertida</label><br>
      <input type="submit" name="converte" id="converte">
    </form>
    <hr>
    <?php
      if(isset($_GET["numero"]) && isset($_GET["base"]) && isset($_GET["converte"])){
        $numero = $_GET["numero"];
        $base = $_GET["base"];
        $converte = $_GET["converte"];

        echo "<p>O resultado é ", base_convert($numero, $base, $converte), "</p>";

      }else{
        echo "Insira um número pelo amor de Deus";
      }


?>
</body>
</html>