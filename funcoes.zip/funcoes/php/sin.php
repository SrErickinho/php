<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sin</title>
    <link rel="stylesheet" href="../css/estilo.css">
</head>
<body>
    <h1>Função sin</h1>
    <br><br>
    <p>A trigonometria é uma parte importante da matemática e as funções matemáticas do PHP nos fornecem algumas funções que são muito úteis para cálculos envolvendo trigonometria. A função sin() no PHP é usada para encontrar o valor do seno de um número.
A função sin() retorna um valor flutuante entre -1 e 1, que representa o seno do ângulo passado como argumento. O parâmetro do argumento deve estar em radianos. </p>
    <p class="sintaxe">float sin($value);</p>   
    <p>Exemplo:</p>
    <p class="exemplo"> echo (sin(3)); </p>
    <p> Vamos calcular:</p>
    <form method="get">
        <label for="x">Insira o valor que deseja saber o seno: </label>
        <input type="number" name="sin" id="sin" class="calculos" required>
        <input type="submit" class="enviar" value="Enviar calculo" required>

        <?php
        $sin= $_GET["sin"];
        echo (sin($sin));
        ?> 


</body>
</html>